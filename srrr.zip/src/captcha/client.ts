import { setTimeout } from "node:timers/promises";
import { parentPort } from "node:worker_threads";
import { chromium, Frame } from "patchright";
import { Utils } from "./utils.js";

const sitekey = "0x4AAAAAADdtWcJatDTtZnkg";

// const browser = await chromium.launch({
//   headless: true,
//   executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH as string,
// });

const context = await chromium.launchPersistentContext("...", {
  channel: "chrome",
  headless: false,
  viewport: null,
});

// const context = await browser.newContext({
//   viewport: {
//     width: 1280,
//     height: 720,
//   },
// });

const page = await context.newPage();

await page.addInitScript((key) => {
  //@ts-ignore
  window.sitekey = key;
}, sitekey);

await page.goto("http://millida.trade:1488");
const utils = new Utils(page);

await utils.waitVisibility("BbLB6", 60_000);
console.log("Successfully waited checkbox!");

const { width, height } = await page
  .locator("#turnstile-widget")
  .evaluate((el) => ({
    width: el.clientWidth,
    height: el.clientHeight,
  }));

const x = width / 10;
const y = height / 3;

await setTimeout(500);

await page.mouse.click(x, y);

await utils.waitVisibility("success", 60_000);

const token = await page.evaluate(() => {
  return document.documentElement.getAttribute("captcha-data");
});

console.log(token);

await context.close();
// await browser.close();

parentPort?.postMessage({ success: true });
